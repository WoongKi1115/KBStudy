주제 : MVC기반의 List를 이용한 전자제품 관리(등록, 수정,삭제, 검색, 부분검색)
  1) 제공해드린   template 프로젝트를  import한다.
  2) classDiagram과 함께 전체적인 구조를 파악한다.
  3) 제공한 ElectronicsService interface 를 보고 기능을 구현한다.
  4) 모두 완성 후 2가지 기능을 생각하여 추가한다. 


*사용자 정의 예외
1. 검색결과 실패
  SearchNotFoundException


2. Electronics의 길이 벗어났을때
   ElectroncisArrayBoundsException


