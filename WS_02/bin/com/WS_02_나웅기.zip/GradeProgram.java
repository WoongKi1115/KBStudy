package com;

import java.util.Scanner;

class CalculateGrade {
	
	// 이름
	String name;
	// 총점 구하기
	private int totalScore(int x, int y, int z) {
		return x + y + z;
	}
	
	// 평균 구하기
	private int scoreAverage(int total, int count) {
		return total / count;
	}
	
	// 등급 구하기
	private char getGrade(int average) {
		char grade = average >= 80 ? 'A' : 'F';
		return grade;
	}
	
	// 이름, 국어, 영어, 수학 출력 
	public void detailGrade(String name, int kor, int eng, int math) {
		this.name = name;
		int total =  this.totalScore(kor, eng, math);
		int avg = this.scoreAverage(total, 3);
		char grade = this.getGrade(avg);
		System.out.println("총점 : " + total);
		System.out.println("평균 : " + avg);
		System.out.println("등급 : " + grade);
	}	
}


public class GradeProgram {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("1. 성적표구하기 2. 종료 ");
		int pick = sc.nextInt();
		if (pick == 1) {
			sc.nextLine();
			String name = sc.nextLine();
			int kor = sc.nextInt();
			int eng = sc.nextInt();
			int math = sc.nextInt();
			CalculateGrade cg = new CalculateGrade();
			cg.detailGrade(name, kor, eng, math);
		} else {
			System.exit(0);
		}
	}

}
