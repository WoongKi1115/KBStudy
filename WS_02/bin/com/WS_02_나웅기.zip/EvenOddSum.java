package com;

import java.io.FileInputStream;
import java.util.Scanner;

public class EvenOddSum {

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("src/com/EvenOddSumInput.txt"));
		Scanner sc = new Scanner(System.in);
		int row = sc.nextInt();
		int array [][] = new int [row][row];
		
		for (int i = 0; i < row + 1; i++) {
			String data = sc.nextLine();
			System.out.println(i + "," + data);
		}
	}

}
